/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package config;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import javax.swing.JOptionPane;

/**
 *
 * @author Muhammad Figo
 */
public class koneksi {
    
    private static Connection cn;
    
    public static Connection getKoneksi(){
        if(cn == null){
            try{
                DriverManager.registerDriver(new com.mysql.jdbc.Driver());
                cn = DriverManager.getConnection("jdbc:mysql://localhost/db_ponsel","root","");
                
            
            }catch(Exception e){
                e.printStackTrace();
            }
        }
        return cn;
    }
    
    
     //Koneksi Login
    Connection con;
    Statement stm;
    
        public void config(){
            try{
                Class.forName("com.mysql.jdbc.Driver");
                con = DriverManager.getConnection("jdbc:mysql://localhost/db_apple","root","");
                stm = con.createStatement();
                
            }catch(Exception e){
                JOptionPane.showMessageDialog(null, "Koneksi Gagal !" +e.getMessage());
            }
        }  
    
}
