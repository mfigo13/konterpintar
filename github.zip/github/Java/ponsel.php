<?php 
	$host = "localhost";
	$user = "root";
	$pass = "";
	$database = "db_ponsel";

	$koneksi = mysqli_connect($host,$user,$pass,$database);
?>

<!DOCTYPE html>
<html>
<head>
	<title>Laporan</title>
	<style type="text/css">fch
	table{
		min-height: 100px;
		border-collapse: collapse;
		font-family: 'Segoe Ui Light' , sans-serif;
		font-weight: 100;
	}
	</style>
</head>
<body>
	<form method="post">
		<hr>
			<h1 align="center" style="font-family: Segoe UI Semibold;">Counter Phone-cell</h1>
			<p style="width: 350px;display: block;margin-right: auto;margin-left: auto;">Jln. merdeka barat nomor 32 sebrang istana merdeka Email:phone-cell@gmail.com</p>
		<hr>
		<table align="center" border="1px" cellpadding="10" cellspacing="0">
			<tr>
				<td>No</td>
				<td>ID Pelanggan</td>
				<td>kode barang</td>
				<td>nama barang</td>
				<td>harga</td>
				<td>jumlah</td>
				<td>total</td>
				<td>bayar</td>
				<td>kembali</td>
				<td>Tanggal</td>
			</tr>
			<?php 
				$sql = "SELECT * FROM tb_transaksi";
				$query = mysqli_query($koneksi,$sql);
				$i=0;
				while($data = mysqli_fetch_array($query)){
				$i++;
			 ?>
			 <tr>
			 	<td><?php echo $i ?></td>
				<td><?php echo $data['id_pelanggan'] ?></td>
				<!-- <td><?php echo $data['nama'] ?></td> -->
				<td><?php echo $data['kd'] ?></td>
				<td><?php echo $data['tipe'] ?></td>
				<td><?php echo $data['harga'] ?></td>
				<td><?php echo $data['jumlah'] ?></td>
				<td><?php echo $data['total'] ?></td>
				<td><?php echo $data['bayar'] ?></td>
				<td><?php echo $data['kembali'] ?></td>
				<td><?php echo $data['tanggal'] ?></td>
			</tr>
			<?php } ?>
		</table>
	</form>
</body>
</html>

<script>
	window.onload=function(){
		window.print();
	}
</script>