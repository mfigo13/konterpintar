-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: 17 Mei 2018 pada 17.24
-- Versi Server: 10.1.30-MariaDB
-- PHP Version: 7.2.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_ponsel`
--

-- --------------------------------------------------------

--
-- Stand-in structure for view `qtransaksi`
-- (Lihat di bawah untuk tampilan aktual)
--
CREATE TABLE `qtransaksi` (
`nama` varchar(50)
,`id` int(3)
,`id_pelanggan` varchar(10)
,`kd` varchar(10)
,`tipe` varchar(30)
,`harga` int(20)
,`jumlah` int(20)
,`total` int(20)
,`bayar` int(20)
,`kembali` int(20)
,`tanggal` timestamp
);

-- --------------------------------------------------------

--
-- Struktur dari tabel `tb_barang`
--

CREATE TABLE `tb_barang` (
  `id` int(3) NOT NULL,
  `kd` varchar(10) NOT NULL,
  `tipe` varchar(30) NOT NULL,
  `harga` int(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `tb_barang`
--

INSERT INTO `tb_barang` (`id`, `kd`, `tipe`, `harga`) VALUES
(1, 'BRNG01', 'Xioami Redmi 2', 1000000),
(2, 'BRNG02', 'Xioami Redmi 3', 2150000),
(3, 'BRNG03', 'Xioami Redmi 4 Prime', 2000000),
(4, 'BRNG04', 'Xioami Redmi 5A', 2500000),
(5, 'BRNG05', 'Xioami Redmi 5 Tab', 3000000),
(6, 'BRNG06', 'Samsung Galaxy ', 2450000),
(7, 'BRNG07', 'Samsung Galaxy A', 1350000),
(8, 'BRNG08', 'Samsung Galaxy z', 6000000),
(9, 'BRNG09', 'Samsung Galaxy 1', 1675000),
(10, '0001', 'I Phone 4', 2000000),
(11, '0002', 'I phone 5', 2500000),
(12, '003', 'I phone 6', 4000000),
(13, '004', 'Advan Vandroid', 1500000),
(14, '0010', 'samsung', 1000000);

-- --------------------------------------------------------

--
-- Struktur dari tabel `tb_pelanggan`
--

CREATE TABLE `tb_pelanggan` (
  `id` int(3) NOT NULL,
  `id_pelanggan` varchar(10) NOT NULL,
  `nama` varchar(50) NOT NULL,
  `jk` varchar(15) NOT NULL,
  `alamat` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `tb_pelanggan`
--

INSERT INTO `tb_pelanggan` (`id`, `id_pelanggan`, `nama`, `jk`, `alamat`) VALUES
(1, 'PLGN01', 'stevan', 'Laki - laki', 'Bogor'),
(2, 'PLGN02', 'Opai', 'Laki - laki', 'Jakarta'),
(3, 'PLGN03', 'Junior', 'Laki - laki', 'Surabaya'),
(4, 'PLNG04', 'Jajang', 'Laki - laki', 'Bogor'),
(5, 'PLGN05', 'Salman', 'Laki - laki', 'Cibedug'),
(7, 'PLGN06', 'Jamal', 'Laki - laki', 'Jakarta'),
(9, 'PLGN07', 'Sesa', 'Perempuan', 'Lampung'),
(10, 'PLGN08', 'Ujank', 'Laki - laki', 'Jakarta'),
(12, 'PLGN09', 'Memunah', 'Perempuan', 'Ciawi'),
(14, 'PLGN10', 'Kalia', 'Perempuan', 'Jakarta');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tb_transaksi`
--

CREATE TABLE `tb_transaksi` (
  `id` int(3) NOT NULL,
  `id_pelanggan` varchar(10) NOT NULL,
  `kd` varchar(10) NOT NULL,
  `tipe` varchar(30) NOT NULL,
  `harga` int(20) NOT NULL,
  `jumlah` int(20) NOT NULL,
  `total` int(20) NOT NULL,
  `bayar` int(20) NOT NULL,
  `kembali` int(20) NOT NULL,
  `tanggal` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `tb_transaksi`
--

INSERT INTO `tb_transaksi` (`id`, `id_pelanggan`, `kd`, `tipe`, `harga`, `jumlah`, `total`, `bayar`, `kembali`, `tanggal`) VALUES
(9, '001', 'BRNG01', 'Xioami Redmi 2', 1000000, 2, 2000000, 3000000, 1000000, '2018-04-22 14:08:13'),
(10, '2', 'BRNG02', 'Xioami Redmi 3', 2150000, 4, 8600000, 10000000, 1400000, '2018-04-22 14:08:54'),
(11, '2', 'BRNG02', 'Xioami Redmi 3', 2150000, 4, 8600000, 10000000, 1400000, '2018-04-22 14:09:24'),
(12, '001', 'BRNG03', 'Xioami Redmi 4 Prime', 2000000, 2, 2000000, 3000000, 1000000, '2018-04-22 14:09:41'),
(13, '001', 'BRNG08', 'Samsung Galaxy z', 6000000, 2, 2000000, 3000000, 1000000, '2018-04-22 14:09:50'),
(14, '3', 'BRNG03', 'Xioami Redmi 4 Prime', 2000000, 2, 4000000, 4000000, 0, '2018-04-22 14:10:17'),
(15, '4', 'BRNG04', 'Xioami Redmi 5A', 2500000, 1, 2500000, 3000000, 500000, '2018-04-22 14:10:42'),
(16, '5', '0001', 'I Phone 4', 2000000, 2, 4000000, 5000000, 1000000, '2018-04-22 14:11:06'),
(17, '5', '0001', 'I Phone 4', 2000000, 2, 4000000, 5000000, 1000000, '2018-04-22 14:11:11'),
(18, '5', 'BRNG05', 'Xioami Redmi 5 Tab', 3000000, 2, 4000000, 5000000, 1000000, '2018-04-22 14:11:21'),
(19, '5', '0001', 'I Phone 4', 2000000, 2, 4000000, 5000000, 1000000, '2018-04-22 14:11:32'),
(20, '5', '0001', 'I Phone 4', 2000000, 1, 2000000, 5000000, 1000000, '2018-04-22 14:11:40'),
(21, '13', 'BRNG09', 'Samsung Galaxy 1', 16750000, 2, 4000000, 5000000, 1000000, '2018-04-22 14:11:58'),
(22, '010', '0001', 'I Phone 4', 2000000, 3, 6000000, 7000000, 1000000, '2018-04-24 02:33:07');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tb_user`
--

CREATE TABLE `tb_user` (
  `username` varchar(20) NOT NULL,
  `password` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `tb_user`
--

INSERT INTO `tb_user` (`username`, `password`) VALUES
('admin', '123'),
('figo', 'figo'),
('user', '123');

-- --------------------------------------------------------

--
-- Struktur untuk view `qtransaksi`
--
DROP TABLE IF EXISTS `qtransaksi`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `qtransaksi`  AS  select `tb_pelanggan`.`nama` AS `nama`,`tb_transaksi`.`id` AS `id`,`tb_transaksi`.`id_pelanggan` AS `id_pelanggan`,`tb_transaksi`.`kd` AS `kd`,`tb_transaksi`.`tipe` AS `tipe`,`tb_transaksi`.`harga` AS `harga`,`tb_transaksi`.`jumlah` AS `jumlah`,`tb_transaksi`.`total` AS `total`,`tb_transaksi`.`bayar` AS `bayar`,`tb_transaksi`.`kembali` AS `kembali`,`tb_transaksi`.`tanggal` AS `tanggal` from (`tb_pelanggan` join `tb_transaksi` on((`tb_pelanggan`.`id_pelanggan` = `tb_transaksi`.`id_pelanggan`))) ;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tb_barang`
--
ALTER TABLE `tb_barang`
  ADD PRIMARY KEY (`id`,`kd`);

--
-- Indexes for table `tb_pelanggan`
--
ALTER TABLE `tb_pelanggan`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tb_transaksi`
--
ALTER TABLE `tb_transaksi`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tb_user`
--
ALTER TABLE `tb_user`
  ADD PRIMARY KEY (`username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tb_barang`
--
ALTER TABLE `tb_barang`
  MODIFY `id` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `tb_pelanggan`
--
ALTER TABLE `tb_pelanggan`
  MODIFY `id` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `tb_transaksi`
--
ALTER TABLE `tb_transaksi`
  MODIFY `id` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
